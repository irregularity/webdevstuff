get_max_return_num() //prompt user for max number

